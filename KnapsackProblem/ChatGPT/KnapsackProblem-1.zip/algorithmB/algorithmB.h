#ifndef ALGORITHM_B_H
#define ALGORITHM_B_H

#include <vector>

int knapsackDP(int capacity, const std::vector<int>& values, const std::vector<int>& weights);

#endif // ALGORITHM_B_H
