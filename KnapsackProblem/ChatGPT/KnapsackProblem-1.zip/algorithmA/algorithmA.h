#ifndef ALGORITHM_A_H
#define ALGORITHM_A_H

#include <vector>

double knapsackGreedy(int capacity, const std::vector<int>& values, const std::vector<int>& weights);

#endif // ALGORITHM_A_H
